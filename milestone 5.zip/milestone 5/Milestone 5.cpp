#include <iostream>
#include <fstream>
#include <sstream>
#include <chrono>
#include <unordered_map>
using namespace std;

struct School {
    string name;
    string address;
    string city;
    string state;
    string county;

    School(string n, string a, string c, string s, string cn)
        : name(n), address(a), city(c), state(s), county(cn) {
    }

    School() : name(""), address(""), city(""), state(""), county("") {}
};

class SchoolList {
public:
    struct Node {
        School school;
        Node* next;

        Node(School s) : school(s), next(nullptr) {}
    };

    Node* head;

    SchoolList() : head(nullptr) {}

    void insertFirst(School school) {
        Node* newNode = new Node(school);
        newNode->next = head;
        head = newNode;
    }

    void insertLast(School school) {
        Node* newNode = new Node(school);
        if (!head) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next) {
            temp = temp->next;
        }
        temp->next = newNode;
    }

    School* findByName(string name) {
        Node* temp = head;
        while (temp) {
            if (temp->school.name == name)
                return &temp->school;
            temp = temp->next;
        }
        return nullptr;
    }

    void deleteByName(string name) {
        if (!head) return;

        if (head->school.name == name) {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }

        Node* temp = head;
        while (temp->next && temp->next->school.name != name) {
            temp = temp->next;
        }

        if (temp->next) {
            Node* toDelete = temp->next;
            temp->next = temp->next->next;
            delete toDelete;
        }
    }

    void display() {
        Node* temp = head;
        while (temp) {
            cout << temp->school.name << " - " << temp->school.address << " - "
                << temp->school.city << " - " << temp->school.state << " - "
                << temp->school.county << endl;
            temp = temp->next;
        }
    }

    ~SchoolList() {
        while (head) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }
};

class HashTable {
public:
    unordered_map<string, School> table;

    void insert(School school) {
        table[school.name] = school;
    }

    School* findByName(string name) {
        if (table.find(name) != table.end()) {
            return &table[name];
        }
        return nullptr;
    }

    void deleteByName(string name) {
        if (table.find(name) != table.end()) {
            table.erase(name);
        }
    }

    void display() {
        for (auto& pair : table) {
            cout << pair.second.name << " - " << pair.second.address << " - "
                << pair.second.city << " - " << pair.second.state << " - "
                << pair.second.county << endl;
        }
    }
};

class BST {
public:
    struct TreeNode {
        School school;
        TreeNode* left;
        TreeNode* right;

        TreeNode(School s) : school(s), left(nullptr), right(nullptr) {}
    };

    TreeNode* root;

    BST() : root(nullptr) {}

    void insert(School school) {
        root = insertRecursive(root, school);
    }

    TreeNode* insertRecursive(TreeNode* node, School school) {
        if (!node) {
            return new TreeNode(school);
        }
        if (school.name < node->school.name) {
            node->left = insertRecursive(node->left, school);
        }
        else {
            node->right = insertRecursive(node->right, school);
        }
        return node;
    }

    School* findByName(string name) {
        TreeNode* node = findRecursive(root, name);
        return node ? &node->school : nullptr;
    }

    TreeNode* findRecursive(TreeNode* node, string name) {
        if (!node || node->school.name == name) return node;
        if (name < node->school.name) return findRecursive(node->left, name);
        return findRecursive(node->right, name);
    }

    void deleteByName(string name) {
        root = deleteRecursive(root, name);
    }

    TreeNode* deleteRecursive(TreeNode* node, string name) {
        if (!node) return node;

        if (name < node->school.name) {
            node->left = deleteRecursive(node->left, name);
        }
        else if (name > node->school.name) {
            node->right = deleteRecursive(node->right, name);
        }
        else {
            if (!node->left) {
                TreeNode* temp = node->right;
                delete node;
                return temp;
            }
            else if (!node->right) {
                TreeNode* temp = node->left;
                delete node;
                return temp;
            }

            TreeNode* temp = findMin(node->right);
            node->school = temp->school;
            node->right = deleteRecursive(node->right, temp->school.name);
        }
        return node;
    }

    TreeNode* findMin(TreeNode* node) {
        while (node && node->left) {
            node = node->left;
        }
        return node;
    }

    void display() {
        displayRecursive(root);
    }

    void displayRecursive(TreeNode* node) {
        if (node) {
            displayRecursive(node->left);
            cout << node->school.name << " - " << node->school.address << " - "
                << node->school.city << " - " << node->school.state << " - "
                << node->school.county << endl;
            displayRecursive(node->right);
        }
    }

    ~BST() {
        destroyTree(root);
    }

    void destroyTree(TreeNode* node) {
        if (node) {
            destroyTree(node->left);
            destroyTree(node->right);
            delete node;
        }
    }
};

void loadFromCSV(const string& filename, SchoolList& list, HashTable& hashTable, BST& bst) {
    ifstream file(filename);
    string line, name, address, city, state, county;

    while (getline(file, line)) {
        stringstream ss(line);
        getline(ss, name, ',');
        getline(ss, address, ',');
        getline(ss, city, ',');
        getline(ss, state, ',');
        getline(ss, county, ',');

        School school(name, address, city, state, county);
        list.insertLast(school);
        hashTable.insert(school);
        bst.insert(school);
    }
}

int main() {
    SchoolList schoolList;
    HashTable hashTable;
    BST bst;
    ofstream comparisonFile("comparison.csv");

    loadFromCSV("Illinois_Schools.csv", schoolList, hashTable, bst);

    cout << "\nLinked List:" << endl;
    schoolList.display();

    cout << "\nHash Table:" << endl;
    hashTable.display();

    cout << "\nBST:" << endl;
    bst.display();

    auto start = chrono::high_resolution_clock::now();
    loadFromCSV("Illinois_Schools.csv", schoolList, hashTable, bst);  
    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double, milli> insertDuration = end - start;
    comparisonFile << "Illinois,Insert,LinkedList," << insertDuration.count() << endl;

    start = chrono::high_resolution_clock::now();
    loadFromCSV("Illinois_Schools.csv", schoolList, hashTable, bst); 
    end = chrono::high_resolution_clock::now();
    chrono::duration<double, milli> insertHTDuration = end - start;
    comparisonFile << "Illinois,Insert,HashTable," << insertHTDuration.count() << endl;

    start = chrono::high_resolution_clock::now();
    loadFromCSV("Illinois_Schools.csv", schoolList, hashTable, bst); 
    end = chrono::high_resolution_clock::now();
    chrono::duration<double, milli> insertBSTDuration = end - start;
    comparisonFile << "Illinois,Insert,BST," << insertBSTDuration.count() << endl;

    string searchName;
    cout << "\nEnter the name of the school to search: ";
    getline(cin, searchName);

    start = chrono::high_resolution_clock::now();
    School* foundSchoolLL = schoolList.findByName(searchName);
    end = chrono::high_resolution_clock::now();
    chrono::duration<double, milli> searchDurationLL = end - start;
    comparisonFile << "Illinois,Search,LinkedList," << searchDurationLL.count() << endl;

    start = chrono::high_resolution_clock::now();
    School* foundSchoolHT = hashTable.findByName(searchName);
    end = chrono::high_resolution_clock::now();
    chrono::duration<double, milli> searchDurationHT = end - start;
    comparisonFile << "Illinois,Search,HashTable," << searchDurationHT.count() << endl;

    start = chrono::high_resolution_clock::now();
    School* foundSchoolBST = bst.findByName(searchName);
    end = chrono::high_resolution_clock::now();
    chrono::duration<double, milli> searchDurationBST = end - start;
    comparisonFile << "Illinois,Search,BST," << searchDurationBST.count() << endl;

    string deleteName;
    cout << "\nEnter the name of the school to delete: ";
    getline(cin, deleteName);

    start = chrono::high_resolution_clock::now();
    schoolList.deleteByName(deleteName);
    end = chrono::high_resolution_clock::now();
    chrono::duration<double, milli> deleteDurationLL = end - start;
    comparisonFile << "Illinois,Delete,LinkedList," << deleteDurationLL.count() << endl;

    start = chrono::high_resolution_clock::now();
    hashTable.deleteByName(deleteName);
    end = chrono::high_resolution_clock::now();
    chrono::duration<double, milli> deleteDurationHT = end - start;
    comparisonFile << "Illinois,Delete,HashTable," << deleteDurationHT.count() << endl;

    start = chrono::high_resolution_clock::now();
    bst.deleteByName(deleteName);
    end = chrono::high_resolution_clock::now();
    chrono::duration<double, milli> deleteDurationBST = end - start;
    comparisonFile << "Illinois,Delete,BST," << deleteDurationBST.count() << endl;

    comparisonFile.close();
    return 0;
}
